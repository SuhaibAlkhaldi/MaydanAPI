namespace Maydan.Domain.Entities;

public class WorkerProjectLink
{
    /// <summary>Surrogate PK — auto-increment identity.</summary>
    public int Id { get; set; }

    // ── Foreign Keys ──────────────────────────────────────────────────────────
    public int ProjectId { get; set; }
    public Project Project { get; set; } = null!;

    public int WorkerId { get; set; }
    public Worker Worker { get; set; } = null!;

    /// <summary>
    /// The service request through which this worker was assigned to the project.
    /// Used to derive DailyWageAmount from ServiceRequest → Service.Price.
    /// </summary>
    public int ServiceRequestId { get; set; }
    public ServiceRequest ServiceRequest { get; set; } = null!;

    // ── Audit Columns ─────────────────────────────────────────────────────────
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    /// <summary>UserId (int FK → User.UserId) of whoever created this link. Null when system-generated.</summary>
    public int? CreatedBy { get; set; }

    /// <summary>UserId (int FK → User.UserId) of whoever last updated this link.</summary>
    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    // ── Business Fields ───────────────────────────────────────────────────────
    /// <summary>
    /// Daily wage for this worker on this project.
    /// Auto-populated from ServiceRequest.Service.Price — NOT manually input.
    /// </summary>
    public decimal DailyWageAmount { get; set; }

    /// <summary>Whether the worker is still active on this project (soft-deactivation).</summary>
    public bool IsWorkerActive { get; set; } = true;
}
