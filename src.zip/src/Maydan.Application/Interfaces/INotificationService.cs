﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maydan.Application.Interfaces
{
    public interface INotificationService
    {
        // يحفظ إشعار لكل مستخدم ويرسل push بالخلفية
        Task NotifyUsersAsync(IEnumerable<int> userIds, string type,
            string titleAr, string titleEn, string bodyAr, string bodyEn,
            object? data = null, CancellationToken ct = default);

        Task RegisterDeviceAsync(int userId, string token, string platform, CancellationToken ct = default);
        Task RemoveDeviceAsync(int userId, string token, CancellationToken ct = default);
        Task<List<NotificationDto>> GetInboxAsync(int userId, bool unreadOnly, int page, int pageSize, CancellationToken ct = default);
        Task<int> GetUnreadCountAsync(int userId, CancellationToken ct = default);
        Task MarkReadAsync(int userId, long notificationId, CancellationToken ct = default);
        Task MarkAllReadAsync(int userId, CancellationToken ct = default);
    }
    public class NotificationDto
    {
        public long Id { get; set; }
        public string Type { get; set; } = "";
        public string TitleAr { get; set; } = ""; public string TitleEn { get; set; } = "";
        public string BodyAr { get; set; } = ""; public string BodyEn { get; set; } = "";
        public string? DataJson { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
    }
    public class RegisterDeviceDto { public string Token { get; set; } = ""; public string Platform { get; set; } = "web"; }
}
