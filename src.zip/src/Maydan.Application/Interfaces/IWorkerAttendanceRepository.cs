﻿using Maydan.Domain.Entities;

namespace Maydan.Application.Interfaces;

public interface IWorkerAttendanceRepository
{
    Task<WorkerAttendance?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<List<WorkerAttendance>> ListByLinkAndDateAsync(int workerProjectLinkId, DateTime date, CancellationToken cancellationToken = default);
    Task<List<WorkerAttendance>> ListByServiceRequestAsync(int serviceRequestId, DateTime from, DateTime to, CancellationToken cancellationToken = default);
    /// <summary>Active link of the worker that owns this QR code on this service request (null if not assigned).</summary>
    Task<WorkerProjectLink?> GetActiveLinkByQrAsync(string qrCode, int serviceRequestId, CancellationToken cancellationToken = default);
    Task<List<WorkerProjectLink>> ListLinksByServiceRequestAsync(int serviceRequestId, CancellationToken cancellationToken = default);
    Task AddAsync(WorkerAttendance attendance, CancellationToken cancellationToken = default);

    Task<List<AttendanceTimeWindow>> ListWindowsForDateAsync(int serviceRequestId, DateTime date, CancellationToken cancellationToken = default);
    Task<List<AttendanceTimeWindow>> ListWindowsAsync(int serviceRequestId, DateTime from, DateTime to, CancellationToken cancellationToken = default);
    Task AddWindowAsync(AttendanceTimeWindow window, CancellationToken cancellationToken = default);
}
