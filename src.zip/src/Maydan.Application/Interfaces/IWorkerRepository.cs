using Maydan.Application.DTOs.Workers;
using Maydan.Domain.Entities;

namespace Maydan.Application.Interfaces;

public interface IWorkerRepository
{
    Task<Worker?> GetByIdAsync(int workerId, CancellationToken cancellationToken = default);
    Task<Worker?> GetByIdWithServicesAsync(int workerId, CancellationToken cancellationToken = default);
    Task<Worker?> GetByIdIncludingDeletedAsync(int workerId, CancellationToken cancellationToken = default);
    Task<Worker?> GetByCivilIdHashAsync(string civilIdHash, CancellationToken cancellationToken = default);
    Task<Worker?> GetByPhoneNumberAsync(string phoneNumber, CancellationToken cancellationToken = default);
    Task<List<Worker>> GetByAssociationIdAsync(int associationId, CancellationToken cancellationToken = default);
    Task<List<Worker>> GetDeletedByAssociationIdAsync(int associationId, CancellationToken cancellationToken = default);

    Task AddAsync(Worker worker, CancellationToken cancellationToken = default);
    void Remove(Worker worker);

    Task<(List<WorkerSummaryDto> Items, int TotalCount)> GetAllProjectedAsync(
        int? associationId, string? search, int? serviceId, int page, int pageSize, CancellationToken cancellationToken = default);


    //---------------------------Service Request Part-----------------
    Task<WorkerDto?> GetByIdProjectedAsync(int workerId, CancellationToken cancellationToken = default);
    Task<List<WorkerDto>> GetAvailableWorkersForRequestAsync(int associationId,int serviceId,DateTime startDate,DateTime endDate,CancellationToken cancellationToken = default);
    Task<Dictionary<int, int>> GetAssociationIdsAsync(IReadOnlyCollection<int> ids, CancellationToken ct = default);
    Task<HashSet<int>> GetBusyWorkerIdsAsync(IReadOnlyCollection<int> ids, DateTime start, DateTime end, CancellationToken ct = default);
    //for assignment workers
    Task<bool> IsWorkerBusyAsync(int workerId, DateTime startDate, DateTime endDate, CancellationToken cancellationToken = default);
}

