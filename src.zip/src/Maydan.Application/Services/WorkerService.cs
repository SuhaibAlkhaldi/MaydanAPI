using Maydan.Application.Common;
using Maydan.Application.DTOs.Common;
using Maydan.Application.DTOs.Workers;
using Maydan.Application.Interfaces;
using Maydan.Domain.Entities;
using Maydan.Domain.Enums;
using System.Text.RegularExpressions;
using System.Threading;

namespace Maydan.Application.Services;

public class WorkerService : IWorkerService
{
    private const int ViewWorkersPermissionId = 23;
    private const int ManageWorkersPermissionId = 24;

    private static readonly int[] ReadScope = { ViewWorkersPermissionId, ManageWorkersPermissionId };
    private static readonly int[] WriteScope = { ManageWorkersPermissionId };

    private static readonly Regex JordanMobileRegex = new(@"^(\+962|0)7[789]\d{7}$", RegexOptions.Compiled);

    private readonly IUnitOfWork _unitOfWork;
    private readonly ICivilIdHasher _civilIdHasher;
    public WorkerService(IUnitOfWork unitOfWork, ICivilIdHasher civilIdHasher)
    {
        _unitOfWork = unitOfWork;
        _civilIdHasher = civilIdHasher;
    }

    public async Task<ApiResponse<PagedResult<WorkerSummaryDto>>> GetAllAsync(int currentUserId, string? search, int? serviceId, int page, int pageSize, CancellationToken cancellationToken = default)
    {
        var (currentUser, authError) = await AuthorizeAsync<PagedResult<WorkerSummaryDto>>(currentUserId, ReadScope, cancellationToken);
        if (authError is not null)
        {
            return authError;
        }

        var (safePage, safePageSize) = Paging.Normalize(page, pageSize);

        var associationScope = currentUser!.EntityType == EntityType.Association ? currentUser.EntityId : (int?)null;
        var (items, totalCount) = await _unitOfWork.Workers.GetAllProjectedAsync(associationScope, search, serviceId, safePage, safePageSize, cancellationToken);

        return ApiResponse<PagedResult<WorkerSummaryDto>>.SuccessResponse(
            new PagedResult<WorkerSummaryDto>(items, totalCount, safePage, safePageSize),
            "Workers retrieved successfully.",
            "تم جلب العمال بنجاح.");
    }

    public async Task<ApiResponse<WorkerDto>> GetByIdAsync(int currentUserId, int workerId, CancellationToken cancellationToken = default)
    {
        var (currentUser, authError) = await AuthorizeAsync<WorkerDto>(currentUserId, ReadScope, cancellationToken);
        if (authError is not null)
        {
            return authError;
        }

        var worker = await _unitOfWork.Workers.GetByIdProjectedAsync(workerId, cancellationToken);
        if (worker is null)
        {
            return ApiResponse<WorkerDto>.FailureResponse("Worker not found.", "العامل غير موجود.");
        }

        var scopeError = EnsureWithinScope<WorkerDto>(currentUser!, worker.AssociationId);
        if (scopeError is not null)
        {
            return scopeError;
        }

        return ApiResponse<WorkerDto>.SuccessResponse(worker, "Worker retrieved successfully.", "تم جلب بيانات العامل بنجاح.");
    }

    public async Task<ApiResponse<WorkerDto>> CreateAsync(int currentUserId, CreateWorkerDto dto, CancellationToken cancellationToken = default)
    {
        var (currentUser, authError) = await AuthorizeAsync<WorkerDto>(currentUserId, WriteScope, cancellationToken);
        if (authError is not null)
        {
            return authError;
        }

        if (string.IsNullOrWhiteSpace(dto.FirstName) || string.IsNullOrWhiteSpace(dto.LastName))
        {
            return ApiResponse<WorkerDto>.FailureResponse("First and last name are required.", "الاسم الأول والأخير مطلوبان.");
        }

        if (string.IsNullOrWhiteSpace(dto.CivilId))
        {
            return ApiResponse<WorkerDto>.FailureResponse("National ID is required.", "الرقم الوطني مطلوب.");
        }

        var phoneServiceError = ValidatePhoneAndServices<WorkerDto>(dto.PhoneNumber, dto.ServiceIds);
        if (phoneServiceError is not null)
        {
            return phoneServiceError;
        }

        var (associationId, associationError) = await ResolveAssociationIdAsync<WorkerDto>(currentUser!, dto.AssociationId, cancellationToken);
        if (associationError is not null)
        {
            return associationError;
        }

        var civilId = dto.CivilId.Trim();
        var civilIdHash = _civilIdHasher.ComputeHash(civilId);
        if (await _unitOfWork.Workers.GetByCivilIdHashAsync(civilIdHash, cancellationToken) is not null)
        {
            return ApiResponse<WorkerDto>.FailureResponse("Worker already exists.", "العامل مسجل مسبقًا بنفس الرقم الوطني.");
        }

        var phoneNumber = dto.PhoneNumber.Trim();
        if (await _unitOfWork.Workers.GetByPhoneNumberAsync(phoneNumber, cancellationToken) is not null)
        {
            return ApiResponse<WorkerDto>.FailureResponse("Phone number is already registered to another worker.", "رقم الهاتف مستخدم مسبقًا لعامل آخر.");
        }

        var genderError = await EnsureLookupItemValidAsync<WorkerDto>("Gender", dto.GenderId, cancellationToken);
        if (genderError is not null)
        {
            return genderError;
        }

        var maritalStatusError = await EnsureLookupItemValidAsync<WorkerDto>("MaritalStatus", dto.MaritalStatusId, cancellationToken);
        if (maritalStatusError is not null)
        {
            return maritalStatusError;
        }

        var serviceIds = dto.ServiceIds.Distinct().ToList();
        var (requiresDocuments, servicesError) = await EnsureServicesExistAsync<WorkerDto>(serviceIds, cancellationToken);
        if (servicesError is not null)
        {
            return servicesError;
        }

        if (!requiresDocuments && dto.DocumentPaths.Count > 0)
        {
            return ApiResponse<WorkerDto>.FailureResponse("The selected services do not require document uploads.", "الخدمات المختارة لا تتطلب رفع وثائق.");
        }

        var documentPaths = requiresDocuments ? dto.DocumentPaths : new List<string>();
        var documentsError = EnsureDocumentCountValid<WorkerDto>(requiresDocuments, documentPaths.Count);
        if (documentsError is not null)
        {
            return documentsError;
        }

        var worker = new Worker
        {
            FirstName = dto.FirstName.Trim(),
            MiddleName = string.IsNullOrWhiteSpace(dto.MiddleName) ? null : dto.MiddleName.Trim(),
            LastName = dto.LastName.Trim(),
            CivilId = civilId,
            CivilIdHash = civilIdHash,
            DateOfBirth = dto.DateOfBirth,
            GenderId = dto.GenderId,
            MaritalStatusId = dto.MaritalStatusId,
            Nationality = dto.Nationality.Trim(),
            PhoneNumber = phoneNumber,
            YearsOfExperience = dto.YearsOfExperience,
            AssociationId = associationId,
            QrCode = Guid.NewGuid().ToString("N"),
            IsActive = true
        };

        foreach (var serviceId in serviceIds)
        {
            worker.WorkerServices.Add(new WorkerServiceLink { ServiceId = serviceId });
        }

        foreach (var path in documentPaths)
        {
            worker.Documents.Add(new WorkerDocument { FilePath = path });
        }

        await _unitOfWork.Workers.AddAsync(worker, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var created = await _unitOfWork.Workers.GetByIdProjectedAsync(worker.Id, cancellationToken);
        return ApiResponse<WorkerDto>.SuccessResponse(created!, "Worker registered successfully.", "تم تسجيل العامل بنجاح.", 201);
    }

    public async Task<ApiResponse<WorkerDto>> UpdateAsync(int currentUserId, int workerId, UpdateWorkerDto dto, CancellationToken cancellationToken = default)
    {
        var (currentUser, authError) = await AuthorizeAsync<WorkerDto>(currentUserId, WriteScope, cancellationToken);
        if (authError is not null)
        {
            return authError;
        }

        if (dto.FirstName is not null && string.IsNullOrWhiteSpace(dto.FirstName))
        {
            return ApiResponse<WorkerDto>.FailureResponse("First name is required.", "الاسم الأول مطلوب.");
        }

        if (dto.LastName is not null && string.IsNullOrWhiteSpace(dto.LastName))
        {
            return ApiResponse<WorkerDto>.FailureResponse("Last name is required.", "الاسم الأخير مطلوب.");
        }

        if (dto.ServiceIds is not null && dto.ServiceIds.Count == 0)
        {
            return ApiResponse<WorkerDto>.FailureResponse("At least one service must be selected.", "يجب اختيار خدمة واحدة على الأقل.");
        }

        var worker = await _unitOfWork.Workers.GetByIdWithServicesAsync(workerId, cancellationToken);
        if (worker is null)
        {
            return ApiResponse<WorkerDto>.FailureResponse("Worker not found.", "العامل غير موجود.");
        }

        var scopeError = EnsureWithinScope<WorkerDto>(currentUser!, worker.AssociationId);
        if (scopeError is not null)
        {
            return scopeError;
        }

        string? phoneNumber = null;
        if (dto.PhoneNumber is not null)
        {
            if (!JordanMobileRegex.IsMatch(dto.PhoneNumber.Trim()))
            {
                return ApiResponse<WorkerDto>.FailureResponse("Phone number must be a valid Jordanian mobile number.", "رقم الهاتف غير صالح، يجب أن يكون رقم أردني.");
            }

            phoneNumber = dto.PhoneNumber.Trim();
            var phoneOwner = await _unitOfWork.Workers.GetByPhoneNumberAsync(phoneNumber, cancellationToken);
            if (phoneOwner is not null && phoneOwner.Id != workerId)
            {
                return ApiResponse<WorkerDto>.FailureResponse("Phone number is already registered to another worker.", "رقم الهاتف مستخدم مسبقًا لعامل آخر.");
            }
        }

        var serviceIds = dto.ServiceIds?.Distinct().ToList() ?? worker.WorkerServices.Select(ws => ws.ServiceId).ToList();
        var (requiresDocuments, servicesError) = await EnsureServicesExistAsync<WorkerDto>(serviceIds, cancellationToken);
        if (servicesError is not null)
        {
            return servicesError;
        }

        if (!requiresDocuments && dto.DocumentPaths.Count > 0)
        {
            return ApiResponse<WorkerDto>.FailureResponse("The selected services do not require document uploads.", "الخدمات المختارة لا تتطلب رفع وثائق.");
        }

        var newDocumentPaths = requiresDocuments ? dto.DocumentPaths : new List<string>();
        var documentsError = EnsureDocumentCountValid<WorkerDto>(requiresDocuments, worker.Documents.Count + newDocumentPaths.Count);
        if (documentsError is not null)
        {
            return documentsError;
        }

        if (dto.FirstName is not null)
        {
            worker.FirstName = dto.FirstName.Trim();
        }

        if (dto.MiddleName is not null)
        {
            worker.MiddleName = string.IsNullOrWhiteSpace(dto.MiddleName) ? null : dto.MiddleName.Trim();
        }

        if (dto.LastName is not null)
        {
            worker.LastName = dto.LastName.Trim();
        }

        if (dto.DateOfBirth is not null)
        {
            worker.DateOfBirth = dto.DateOfBirth.Value;
        }

        if (dto.GenderId is not null)
        {
            var genderError = await EnsureLookupItemValidAsync<WorkerDto>("Gender", dto.GenderId.Value, cancellationToken);
            if (genderError is not null)
            {
                return genderError;
            }

            worker.GenderId = dto.GenderId.Value;
        }

        if (dto.MaritalStatusId is not null)
        {
            var maritalStatusError = await EnsureLookupItemValidAsync<WorkerDto>("MaritalStatus", dto.MaritalStatusId.Value, cancellationToken);
            if (maritalStatusError is not null)
            {
                return maritalStatusError;
            }

            worker.MaritalStatusId = dto.MaritalStatusId.Value;
        }

        if (dto.Nationality is not null)
        {
            worker.Nationality = dto.Nationality.Trim();
        }

        if (phoneNumber is not null)
        {
            worker.PhoneNumber = phoneNumber;
        }

        if (dto.YearsOfExperience is not null)
        {
            worker.YearsOfExperience = dto.YearsOfExperience.Value;
        }

        if (dto.ServiceIds is not null)
        {
            SyncWorkerServices(worker, serviceIds);
        }

        foreach (var path in newDocumentPaths)
        {
            worker.Documents.Add(new WorkerDocument { WorkerId = worker.Id, FilePath = path });
        }

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var updated = await _unitOfWork.Workers.GetByIdProjectedAsync(worker.Id, cancellationToken);
        return ApiResponse<WorkerDto>.SuccessResponse(updated!, "Worker updated successfully.", "تم تحديث بيانات العامل بنجاح.");
    }

    public async Task<ApiResponse<object?>> DeleteAsync(int currentUserId, int workerId, CancellationToken cancellationToken = default)
    {
        var (currentUser, authError) = await AuthorizeAsync<object?>(currentUserId, WriteScope, cancellationToken);
        if (authError is not null)
        {
            return authError;
        }

        var worker = await _unitOfWork.Workers.GetByIdWithServicesAsync(workerId, cancellationToken);
        if (worker is null)
        {
            return ApiResponse<object?>.FailureResponse("Worker not found.", "العامل غير موجود.");
        }

        var scopeError = EnsureWithinScope<object?>(currentUser!, worker.AssociationId);
        if (scopeError is not null)
        {
            return scopeError;
        }

        // Cascading the soft-delete to Documents/WorkerServices happens inside
        // WorkerRepository.Remove (needs direct DbContext access to avoid EF's "severed required
        // relationship" error — see its own comment for why).
        _unitOfWork.Workers.Remove(worker);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return ApiResponse<object?>.SuccessResponse(null, "Worker deleted successfully.", "تم حذف العامل بنجاح.");
    }

    public async Task<ApiResponse<WorkerDto>> RestoreAsync(int currentUserId, int workerId, CancellationToken cancellationToken = default)
    {
        var (currentUser, authError) = await AuthorizeAsync<WorkerDto>(currentUserId, WriteScope, cancellationToken);
        if (authError is not null)
        {
            return authError;
        }

        var worker = await _unitOfWork.Workers.GetByIdIncludingDeletedAsync(workerId, cancellationToken);
        if (worker is null)
        {
            return ApiResponse<WorkerDto>.FailureResponse("Worker not found.", "العامل غير موجود.");
        }

        var scopeError = EnsureWithinScope<WorkerDto>(currentUser!, worker.AssociationId);
        if (scopeError is not null)
        {
            return scopeError;
        }

        if (!worker.IsDeleted)
        {
            return ApiResponse<WorkerDto>.FailureResponse("Worker is not deleted.", "العامل غير محذوف أصلًا.");
        }

        worker.IsDeleted = false;
        worker.DeletedAt = null;

        foreach (var document in worker.Documents)
        {
            document.IsDeleted = false;
            document.DeletedAt = null;
        }

        foreach (var link in worker.WorkerServices)
        {
            link.IsDeleted = false;
            link.DeletedAt = null;
        }

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var restored = await _unitOfWork.Workers.GetByIdProjectedAsync(worker.Id, cancellationToken);
        return ApiResponse<WorkerDto>.SuccessResponse(restored!, "Worker restored successfully.", "تم استرجاع العامل بنجاح.");
    }

    private async Task<(User? User, ApiResponse<T>? Error)> AuthorizeAsync<T>(int currentUserId, int[] anyOfPermissionIds, CancellationToken cancellationToken)
    {
        var currentUser = await _unitOfWork.Users.GetWithPermissionsAsync(currentUserId, cancellationToken);
        if (currentUser is null)
        {
            return (null, ApiResponse<T>.FailureResponse("Current user was not found.", "المستخدم الحالي غير موجود."));
        }

        if (!currentUser.IsActive)
        {
            return (null, ApiResponse<T>.FailureResponse("Current user is inactive.", "المستخدم الحالي غير فعّال."));
        }

        if (!GetEffectivePermissionIds(currentUser).Overlaps(anyOfPermissionIds))
        {
            return (null, ApiResponse<T>.FailureResponse("You do not hold the required Workers permission.", "لا تملك الصلاحية المطلوبة لإدارة العمال."));
        }

        return (currentUser, null);
    }

    private async Task<(int AssociationId, ApiResponse<T>? Error)> ResolveAssociationIdAsync<T>(User currentUser, int? requestedAssociationId, CancellationToken cancellationToken)
    {
        if (currentUser.EntityType == EntityType.Association)
        {
            if (requestedAssociationId.HasValue && requestedAssociationId.Value != currentUser.EntityId)
            {
                return (0, ApiResponse<T>.FailureResponse("You cannot register a worker under a different association.", "لا يمكنك تسجيل عامل تحت جمعية أخرى."));
            }

            return (currentUser.EntityId, null);
        }

        if (!requestedAssociationId.HasValue)
        {
            return (0, ApiResponse<T>.FailureResponse("You must select an association.", "يجب اختيار الجمعية عند إضافة عامل."));
        }

        var association = await _unitOfWork.Associations.GetByIdAsync(requestedAssociationId.Value, cancellationToken);
        if (association is null)
        {
            return (0, ApiResponse<T>.FailureResponse("Association not found.", "الجمعية غير موجودة."));
        }

        return (association.Id, null);
    }

    private static ApiResponse<T>? EnsureWithinScope<T>(User currentUser, int workerAssociationId)
    {
        if (currentUser.EntityType == EntityType.Association && workerAssociationId != currentUser.EntityId)
        {
            return ApiResponse<T>.FailureResponse("Cannot access a worker outside your own association.", "لا يمكنك الوصول إلى عامل خارج جمعيتك.");
        }

        return null;
    }

    private static HashSet<int> GetEffectivePermissionIds(User user)
    {
        // modify cause i modified a get with permission async in user repository to get the permission to users that is active in system


        var rolePermissionIds = user.Role?.RolePermissions?
        .Where(rp => rp.IsActive && (rp.Permission == null || rp.Permission.IsActive))
        .Select(rp => rp.PermissionId) ?? Enumerable.Empty<int>();

        var directPermissionIds = user.UserPermissions?
        .Where(up => up.IsActive && (up.Permission == null || up.Permission.IsActive))
        .Select(up => up.PermissionId) ?? Enumerable.Empty<int>();

        var groupPermissionIds = user.UserGroups?
        .Where(ug => ug.Group != null && ug.Group.IsActive)
        .SelectMany(ug => ug.Group.GroupPermissions ?? new List<GroupPermission>())
        .Where(gp => gp.IsActive && (gp.Permission == null || gp.Permission.IsActive))
        .Select(gp => gp.PermissionId) ?? Enumerable.Empty<int>();
        // why Enumerable not queryable cause in this momment data in memory not in the database

        return rolePermissionIds.Concat(directPermissionIds).Concat(groupPermissionIds).ToHashSet();
    }

    private async Task<ApiResponse<T>?> EnsureLookupItemValidAsync<T>(string categoryCode, int itemId, CancellationToken cancellationToken)
    {
        var exists = await _unitOfWork.Lookups.ExistsInCategoryAsync(categoryCode, itemId, cancellationToken);
        if (!exists)
        {
            return categoryCode switch
            {
                "Gender" => ApiResponse<T>.FailureResponse("Gender is invalid.", "الجنس المحدد غير صالح."),
                "MaritalStatus" => ApiResponse<T>.FailureResponse("Marital status is invalid.", "الحالة الاجتماعية المحددة غير صالحة."),
                _ => ApiResponse<T>.FailureResponse("Selected value is invalid.", "القيمة المحددة غير صالحة.")
            };
        }

        return null;
    }

    private async Task<(bool RequiresDocuments, ApiResponse<T>? Error)> EnsureServicesExistAsync<T>(List<int> serviceIds, CancellationToken cancellationToken)
    {
        var requiresDocuments = false;

        foreach (var serviceId in serviceIds)
        {
            var service = await _unitOfWork.Services.GetByIdAsync(serviceId, cancellationToken);
            if (service is null)
            {
                return (false, ApiResponse<T>.FailureResponse("One or more selected services were not found.", "إحدى الخدمات المحددة غير موجودة."));
            }

            if (service.RequiresDocuments)
            {
                requiresDocuments = true;
            }
        }

        return (requiresDocuments, null);
    }

    private const int MaxWorkerDocuments = 4;

    private static ApiResponse<T>? EnsureDocumentCountValid<T>(bool requiresDocuments, int totalCount)
    {
        if (requiresDocuments && totalCount == 0)
        {
            return ApiResponse<T>.FailureResponse("At least one document must be uploaded for this service.", "يجب رفع صورة واحدة على الأقل لهذه الخدمة.");
        }

        if (totalCount > MaxWorkerDocuments)
        {
            return ApiResponse<T>.FailureResponse($"At most {MaxWorkerDocuments} documents may be uploaded.", $"الحد الأقصى {MaxWorkerDocuments} صور.");
        }

        return null;
    }

    private static ApiResponse<T>? ValidatePhoneAndServices<T>(string phoneNumber, List<int> serviceIds)
    {
        if (string.IsNullOrWhiteSpace(phoneNumber) || !JordanMobileRegex.IsMatch(phoneNumber.Trim()))
        {
            return ApiResponse<T>.FailureResponse("Phone number must be a valid Jordanian mobile number.", "رقم الهاتف غير صالح، يجب أن يكون رقم أردني.");
        }

        if (serviceIds.Count == 0)
        {
            return ApiResponse<T>.FailureResponse("At least one service must be selected.", "يجب اختيار خدمة واحدة على الأقل.");
        }

        return null;
    }

    private static void SyncWorkerServices(Worker worker, List<int> serviceIds)
    {
        var requestedIds = serviceIds.ToHashSet();
        var existingIds = worker.WorkerServices.Select(ws => ws.ServiceId).ToHashSet();

        foreach (var link in worker.WorkerServices.Where(ws => !requestedIds.Contains(ws.ServiceId)).ToList())
        {
            worker.WorkerServices.Remove(link);
        }

        foreach (var serviceId in requestedIds.Except(existingIds))
        {
            worker.WorkerServices.Add(new WorkerServiceLink { WorkerId = worker.Id, ServiceId = serviceId });
        }
    }

    private async Task<(User? CurrentUser, ApiResponse<T>? Error)> GetCurrentUserAsync<T>(int currentUserId, CancellationToken cancellationToken)
    {
        var currentUser = await _unitOfWork.Users.GetWithPermissionsAsync(currentUserId, cancellationToken);
        if (currentUser is null) { return (null, ApiResponse<T>.FailureResponse("لم يتم العثور على المستخدم الحالي.", "Current user was not found.")); }
        if (!currentUser.IsActive)
        {
            return (null, ApiResponse<T>.FailureResponse("حساب المستخدم الحالي غير نشط.", "Current user is inactive."));
        }
        return (currentUser, null);
    }
    public async Task<ApiResponse<List<WorkerDto>>> GetAvailableWorkersForRequestAsync(
     int currentUserId,
     int serviceRequestId,
     CancellationToken cancellationToken = default)
    {
        var request = await _unitOfWork.ServiceRequests
            .GetByIdAsync(serviceRequestId, cancellationToken);

        if (request is null)
        {
            return ApiResponse<List<WorkerDto>>.FailureResponse(
                "Request not found.",
                "الطلب غير موجود.");
        }

        // Check that the current user is an Association admin
        // belonging to the same association as the service request.
        var (currentUser, authError) =
            await GetCurrentUserAsync<List<WorkerDto>>(
                currentUserId,
                cancellationToken);

        if (authError is not null)
            return authError;

        if (currentUser!.EntityType != EntityType.Association ||
            currentUser.EntityId != request.AssociationId)
        {
            return ApiResponse<List<WorkerDto>>.FailureResponse(
                "You are not authorized to view workers for this service request.",
                "ليس لديك صلاحية لعرض عمال طلب الخدمة هذا.");
        }

       

        var workers = await _unitOfWork.Workers.GetAvailableWorkersForRequestAsync(
     request.AssociationId,
     request.ServiceId,
     request.StartDate,
     request.EndDate,
     cancellationToken);
        return ApiResponse<List<WorkerDto>>.SuccessResponse(
            workers,
            "Available workers retrieved successfully.",
            "تم استرجاع العمال المتاحين بنجاح.");
    }
}
