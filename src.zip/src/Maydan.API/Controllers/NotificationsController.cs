﻿using Maydan.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Maydan.API.Controllers
{
    [Authorize]
    [Route("api/notifications")]
    public class NotificationsController : ApiControllerBase
    {
        private readonly INotificationService _notifications;
        public NotificationsController(INotificationService notifications) => _notifications = notifications;

        private ActionResult NoUser() => Unauthorized();   // خليه بنفس شكل الـ NoUser عندك بالـ AttendanceController

        [HttpPost("devices")]
        public async Task<IActionResult> RegisterDevice([FromBody] RegisterDeviceDto dto, CancellationToken ct)
        {
            if (!TryGetCurrentUserId(out var uid)) return NoUser();
            if (string.IsNullOrWhiteSpace(dto.Token)) return BadRequest();
            await _notifications.RegisterDeviceAsync(uid, dto.Token.Trim(), dto.Platform, ct);
            return NoContent();
        }

        [HttpDelete("devices")]
        public async Task<IActionResult> RemoveDevice([FromBody] RegisterDeviceDto dto, CancellationToken ct)
        {
            if (!TryGetCurrentUserId(out var uid)) return NoUser();
            await _notifications.RemoveDeviceAsync(uid, dto.Token, ct);
            return NoContent();
        }

        [HttpGet]
        public async Task<IActionResult> Inbox([FromQuery] bool unreadOnly = false, [FromQuery] int page = 1, [FromQuery] int pageSize = 20, CancellationToken ct = default)
        {
            if (!TryGetCurrentUserId(out var uid)) return NoUser();
            return Ok(await _notifications.GetInboxAsync(uid, unreadOnly, page, Math.Clamp(pageSize, 1, 50), ct));
        }

        [HttpGet("unread-count")]
        public async Task<IActionResult> UnreadCount(CancellationToken ct)
        {
            if (!TryGetCurrentUserId(out var uid)) return NoUser();
            return Ok(new { count = await _notifications.GetUnreadCountAsync(uid, ct) });
        }

        [HttpPost("{id:long}/read")]
        public async Task<IActionResult> MarkRead(long id, CancellationToken ct)
        {
            if (!TryGetCurrentUserId(out var uid)) return NoUser();
            await _notifications.MarkReadAsync(uid, id, ct);
            return NoContent();
        }

        [HttpPost("read-all")]
        public async Task<IActionResult> MarkAllRead(CancellationToken ct)
        {
            if (!TryGetCurrentUserId(out var uid)) return NoUser();
            await _notifications.MarkAllReadAsync(uid, ct);
            return NoContent();
        }
    }
}
