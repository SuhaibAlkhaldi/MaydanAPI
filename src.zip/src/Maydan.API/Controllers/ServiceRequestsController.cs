using Azure;
using FluentValidation;
using FluentValidation.Results;
using Maydan.Application.DTOs.Common;
using Maydan.Application.DTOs.ServiceRequests;
using Maydan.Application.Interfaces;
using Maydan.Application.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Maydan.API.Controllers;

[Authorize]
[Route("api/[controller]")]
public class ServiceRequestsController : ApiControllerBase
{
    private readonly IServiceRequestService _serviceRequestService;
    private readonly CreateServiceRequestDtoValidator _createValidator;

    public ServiceRequestsController(IServiceRequestService serviceRequestService, CreateServiceRequestDtoValidator createValidator)
    {
        _serviceRequestService = serviceRequestService;
        _createValidator = createValidator;
    }



    [HttpGet("resolve-association")]
    public async Task<ActionResult<AssociationLookupDto>> ResolveAssociation([FromQuery] int cityId, CancellationToken cancellationToken)
    {
        if (!TryGetCurrentUserId(out var currentUserId))
        {
            return Unauthorized(new Maydan.Application.DTOs.Common.ApiResponse<object?>(false, " تعذر التحقق من هوية المستخدم  ", "Current user id is required.", null));
        }


        var result = await _serviceRequestService.ResolveAssociationByCityIdAsync(currentUserId, cityId, cancellationToken);
        return StatusCode(result.StatusCode, result);


    }
    [HttpPost("{id:int}/approve-and-assign")]
    public async Task<IActionResult> ApproveAndAssign(int id, [FromBody] List<int> workerIds, CancellationToken cancellationToken)
    {
        if (!TryGetCurrentUserId(out var currentUserId))
            return Unauthorized(new ApiResponse<object?>(false, "تعذر التحقق من هوية المستخدم", "Current user id is required.", null));

        var response = await _serviceRequestService.ApproveAndAssignAsync(
            currentUserId,
            id,
            workerIds,
            cancellationToken);

        return StatusCode(response.StatusCode, response);
    }

    [HttpPost]
    public async Task<ActionResult<ServiceRequestDto>> Create([FromBody] CreateServiceRequestDto dto, CancellationToken cancellationToken)
    {
        if (!TryGetCurrentUserId(out var currentUserId))
        {
            return Unauthorized(new Maydan.Application.DTOs.Common.ApiResponse<object?>(false, "  تعذر التحقق من هوية المستخدم ", "Current user id is required.", null));
        }
        // validate input using the concrete validator
        var validation = await _createValidator.ValidateAsync(dto, cancellationToken);
        if (!validation.IsValid)
        {
            var errors = validation.Errors.Select(e => new { field = e.PropertyName, error = e.ErrorMessage }).ToList();
            return BadRequest(new Maydan.Application.DTOs.Common.ApiResponse<object?>(false, "البيانات المدخلة غير صحيحة او غير مطابقة", "Validation failed.", errors));
        }


        var result = await _serviceRequestService.CreateAsync(currentUserId, dto, cancellationToken);
        if (!result.Success)
        {
            return StatusCode(result.StatusCode, result);
        }
        return CreatedResponse(
$"/api/ServiceRequests/{result.Data!.Id}",
result);

    }

    [HttpPost("calculate-expected-payment")]
    public async Task<ActionResult<ExpectedPaymentCalculationDto>> Calculate([FromBody] CalculationRequestDto dto, CancellationToken cancellationToken)
    {

        if (!TryGetCurrentUserId(out var currentUserId))
        {
            return Unauthorized(new Maydan.Application.DTOs.Common.ApiResponse<object?>(false, "  تعذر التحقق من هوية المستخدم ", "Current user id is required.", null));
        }

        var calculationResult = await _serviceRequestService.CalculateExpectedPaymentAsync(currentUserId, dto.ServiceId, dto.RequestedWorkers, dto.DurationCount, cancellationToken);
        return StatusCode(calculationResult.StatusCode, calculationResult);

    }

    [HttpGet]
    public async Task<ActionResult<List<ServiceRequestDto>>> GetAll(CancellationToken cancellationToken)
    {
        if (!TryGetCurrentUserId(out var currentUserId))
        {
            return Unauthorized(new Maydan.Application.DTOs.Common.ApiResponse<object?>(false, "تعذر التحقق من هوية المستخدم", "Current user id is required.", null));
        }


        var response = await _serviceRequestService.GetAllAsync(currentUserId, cancellationToken);

        return StatusCode(response.StatusCode, response);
    }




    [HttpGet("{id:int}")]
    public async Task<ActionResult<ServiceRequestDetailsDto>> GetById(int id, CancellationToken cancellationToken)
    {
        if (!TryGetCurrentUserId(out var currentUserId))
        {
            return Unauthorized(new Maydan.Application.DTOs.Common.ApiResponse<object?>(false, "تعذر التحقق من هوية المستخدم", "Current user id is required.", null));
        }

        var response = await _serviceRequestService.GetByIdAsync(currentUserId, id, cancellationToken);

        return StatusCode(response.StatusCode, response);
    }



    [HttpPost("{id:int}/cancel")]
    public async Task<ActionResult> Cancel(int id, CancellationToken cancellationToken)
    {
        if (!TryGetCurrentUserId(out var currentUserId))
        {
            return Unauthorized(new Maydan.Application.DTOs.Common.ApiResponse<object?>(false, "تعذر التحقق من هوية المستخدم", "Current user id is required.", null));

        }


        var response = await _serviceRequestService.CancelAsync(currentUserId, id, cancellationToken);

        return StatusCode(response.StatusCode, response);


    }

    [HttpPost("{id:int}/reject")]
    public async Task<ActionResult> Reject(int id, [FromBody] string? reason, CancellationToken cancellationToken)
    {
        if (!TryGetCurrentUserId(out var currentUserId))
            return Unauthorized(new ApiResponse<object?>(false, "تعذر التحقق من هوية المستخدم", "Current user id is required.", null));
        var response = await _serviceRequestService.RejectAsync(currentUserId, id, reason, cancellationToken);
        return StatusCode(response.StatusCode, response);
    }

    //[HttpPost("{id:int}/approve")]
    //public async Task<ActionResult> Approve(int id, CancellationToken cancellationToken)
    //{
    //    if (!TryGetCurrentUserId(out var currentUserId))
    //        return Unauthorized(new ApiResponse<object?>(false, "تعذر التحقق من هوية المستخدم", "Current user id is required.", null));
    //    var response = await _serviceRequestService.ApproveAsync(currentUserId, id, cancellationToken);
    //    return StatusCode(response.StatusCode, response);
    //}

}
